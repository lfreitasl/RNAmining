name = "rnamining"
__author__ = """Thaís de Almeida Ratis Ramos"""
__email__ = "thaisratis@gmail.com"
__version__ = "1.0.4"