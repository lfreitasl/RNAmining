"""
rnamining module containing trained models
"""

from pathlib import Path

HERE = Path(__file__).parent.resolve()

