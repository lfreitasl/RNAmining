from sys import argv
import sys
import os


file = argv[1]

arq = open(file, 'r')

for i in arq:
	print (i)